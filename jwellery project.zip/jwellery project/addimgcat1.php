<?php
	$con = mysqli_connect("localhost","root","","jwellery");
	if(move_uploaded_file($_FILES['img']['tmp_name'],"jwellpics/".$_FILES['img']['name']))
	{
		$type = $_POST["type"];
		$name=$_POST["name"];
		$price=$_POST["price"];
		$weight=$_POST["weight"];
		$img= $_FILES['img']['name'];
		
		$sql = "INSERT INTO `catimg`( `type`, `name`, `price`, `weight`, `img`) VALUES ('$type','$name','$price','$weight','$img')";
		$rs = mysqli_query($con,$sql);
		if($rs)
			//echo "insert";
			header("location:addimgcat.php");
	}
	else
		echo "not upload";
?>