<!doctype html>
<head>
		<meta charset="UTF-8">
    	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/home.css">		
</head>
<title>Shivam Jewellery</title>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark  ">
	<img src="images/shiva.jpg" >	
  <a class="navbar-brand " style="font-family:cursive ;font-size: 1.5em;" href="#">Shivam Jewellery</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item ">
        <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
      </li>

        <li class="nav-item">
			<a class="nav-link" href="gallery.php">Gallery</a>
		</li>			
		<li class="nav-item">
			<a class="nav-link" href="contactus.php">Contact Us</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="adminlogout.php">Log Out</a>
		</li>
	</ul>
  </div>
  		<span class="navbar-text">
                  <!-- Button login modal -->
            <button type="button" class="btn btn-warning mr-2" data-toggle="modal" data-target="#loginModal">
                Login
              </button>
            <!-- Button signup modal -->
            <button type="button" class="btn btn-warning mr-2" data-toggle="modal" data-target="#signupModal">
                SignUp
            </button>
		  </span>
</nav>	
<div id="loginModal" class="modal fade" role="dialog">
        <div class=" modal-dialog modal-lg" role="content">
            <div class="modal-content">
                <div class="modal-header bg-secondary">
                    <h4 class="modal-title text-light">Login</h4>
                    <button type="button" class="close text-white" data-dismiss="modal">
                          &times;
                      </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label class="sr-only" for="email">Email address:</label>
                            <input type="email" class="form-control" placeholder="Enter email" id="email">
                        </div>
                        <div class="form-group">
                            <label class="sr-only" for="pwd">Password:</label>
                            <input type="password" class="form-control" placeholder="Enter password" id="pwd">
                        </div>
                        <div class="col-sm-auto">
                            <div class=" form-check">
                                <label class="form-check-label">
                                   <input class="form-check-input" type="checkbox"> Remember me
                              </label>
                            </div>
                        </div>
                        <div class="form-row">
                            <button type="button" class="btn btn-secondary ml-auto" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary ml-2">Sign In</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!--signup Modal -->
    <div class="modal fade" id="signupModal" role="dialog">
        <div class="modal-dialog modal-dialog-scrollable modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-secondary">
                    <h5 class="modal-title text-white" id="signupModalTitle">SignUp Here</h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>

                </div>
                <div class="modal-body">

                    <form>
                        <div class="form-group">
                            <label for="Username">UserName</label>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Choose a unique Username" required>
                        </div>

                        <div class="form-group">
                            <label for="Firstname">FirstName</label>
                            <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Firstname">
                        </div>
                        <div class="form-group">
                            <label for="Lastname">LastName</label>
                            <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Lastname">
                        </div>
                        <div class="form-group">
                            <label for="Email">Email address</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                        </div>

                        <div class="form-group">
                            <label for="Password1"> Choose a Password</label>
                            <input type="password" class="form-control" id="password1" name="password1" placeholder="Choose your Password" required>
                        </div>

                        <div class="form-group">
                            <label for="Password2"> Confirm Password</label>
                            <input type="password" class="form-control" id="password2" name="password2" placeholder="Enter Password Again" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-primary ml-3">Close</button>
                    </form>
                </div>
            </div>
        </div>
	</div>
	
	<div class="p-2">
	<div class="container-fluid  rounded-circle bg-warning">
			<img class="rounded mx-auto d-block " src="images/download.png" >
		</div>
	</div>

<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/background.jpg" alt="Los Angeles" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Elite Collections</h3>
        <p>Special Discount On Festivals</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="images/cr2.png" alt="Chicago" width="1100" height="500">
      <!-- <div class="carousel-caption">
        <h3>Chicago</h3>
        <p>Thank you, Chicago!</p>
      </div>    -->
    </div>
    <div class="carousel-item">
      <img src="images/cr1.png" alt="New York" width="1100" height="500">
      <!-- <div class="carousel-caption">
        <h3>New York</h3>
        <p>We love the Big Apple!</p>
      </div>    -->
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

	<div class="pt-4">
	<div class="container-fluid ">
		<p class="font-italic text-center" style="font-size: 2.5em;">Shivam Elite Collections</p>
		<h4 class="text-center mx-5">Showcased by Bollywood royalty, available to a chosen few. These timeless pieces represent the pinnacle of design and craft at Shivam. We present to you the finest jewellery from Shivam that is as exclusive
			 as it is exquisite. There is literally nothing like it in the world.</h4>
	</div>
	</div>	

    <!--carousel wrapper-->
	<div id="mycarousel" class="carousel slide my-5" data-ride=2000>
	<p class="text-center" style=" font-family:Georgia, 'Times New Roman', Times, serif ;font-size: 3em;">Top Sellers</p>
        <!--Indicators-->
        <ol class="carousel-indicators">
            <li data-target="#multi-item-example" data-slide-to="0" class="active"></li>
            <li data-target="#multi-item-example" data-slide-to="1"></li>
        </ol>
        <!--/.Indicators-->

        <!--Slides-->
        <div class="carousel-inner mt-5" role="listbox">

            <!--First slide-->
            <div class="carousel-item active">

                <div class="col-md-3" style="float:left">
                    <div class="card cd1 mb-2">
                        <img class="card-img-top " src="images/bangles1.jpg" style="height:220px">
                        <div class="card-body">
                            <h4 class="card-title">BANGLES</h4>
                            <p class="card-text"></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3" style="float:left">
                    <div class="card cd1 mb-2">
                        <img class="card-img-top" src="images/braclet1.jpg" style="height:220px">
                        <div class="card-body">
                            <h4 class="card-title">BRACLET</h4>
                            <p class="card-text"></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3" style="float:left">
                    <div class="card cd1 mb-2">
                        <img class="card-img-top" src="images/necklace.jpg" style="height:220px">
                        <div class="card-body">
                            <h4 class="card-title">NECKLACE</h4>
                            <p class="card-text"></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3" style="float:left">
                    <div class="card cd1 mb-2">
                        <img class="card-img-top" src="images/ring.jpg" style="height:220px">
                        <div class="card-body">
                            <h4 class="card-title">RING</h4>
                            <p class="card-text"></p>
                        </div>
                    </div>
                </div>

            </div>
            <!--/.First slide-->

            <!--Second slide-->
            <div class="carousel-item">

                <div class="col-md-3" style="float:left">
                    <div class="card cd1 mb-2">
                        <img class="card-img-top" src="images/bangles2.jpg" style="height:220px">
                        <div class="card-body">
                            <h4 class="card-title">BANGLES</h4>
                            <p class="card-text"></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3" style="float:left">
                    <div class="card cd1 mb-2">
                        <img class="card-img-top" src="images/earrings1.jpg" style="height:220px">
                        <div class="card-body">
                            <h4 class="card-title">EARRINGS </h4>
                            <p class="card-text"></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3" style="float:left">
                    <div class="card cd1 mb-2">
                        <img class="card-img-top" src="images/necklace4.jpg" style="height:220px">
                        <div class="card-body">
                            <h4 class="card-title">NECKLACE</h4>
                            <p class="card-text"></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3" style="float:left">
                    <div class="card cd1 mb-2">
                        <img class="card-img-top" src="images/ring2.jpg" style="height:220px">
                        <div class="card-body">
                            <h4 class="card-title">RING</h4>
                            <p class="card-text"></p>
                        </div>
                    </div>
                </div>
            </div>
            <!--/.Second slide-->
            <!--/.Slides-->
        </div>

        <a class="carousel-control-prev " href="#mycarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>

        <a class="carousel-control-next" href="#mycarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
	</div>

	<div class="pb-3">
		<div class="container-fluid ">
		<p class="text-center" style=" font-family:Georgia, 'Times New Roman', Times, serif ;font-size: 3em;">OUR PROMISES</p>
			<div class=" rounded-pill bg-dark row">
				<div class="col-lg-3 col-md-3 col-12 m-5 text-center text-white">
						<p>100% ORIGINAL</p>
					<h4>All products are original and go through strict quality check.</h4>
				</div>
				<div class="col-lg-3 col-md-3 col-12 m-5 text-center text-white">
						<p>A TATA PRODUCT</p>
					<h4>The Tata seal of Trust comes with all our products</h4>
				</div>
				<div class="col-lg-3 col-md-3 col-12 m-5 text-center text-white">
						<p>SHIPPING</p>
					<h4>We provide the facility of free Shipping to all corners of India.</h4>
				</div>
			</div>
		</div>
	</div>

	   <!--footer-->
	   <div class="jumbotron-fluid bg-warning" style="height: 50px;">
    </div>
    <footer class="footer bg-dark ">
        <div class="container py-5">
            <div class="row text-white ">
                <div class="col-3 offset-1 col-sm-2 ">
                    <h5>Links</h5>
                    <ul class="list-unstyled ">
                        <li><a href="home.php" class="text-white ">Home</a></li>
                        <li><a href="gallery.php" class="text-white">Gallery</a></li>
                        <li><a href="contactus.php" class="text-white ">Contact</a></li>
                        <li><a href="#" class="text-white ">Logout</a></li>
                    </ul>
                </div>
                <div class="col col-md-3">
                    <h5>Other Products</h5>
                  <ul class="list-unstyled ">
                    <li><a href="#"class="text-white font-italic ">Re Selling On Exchange</a></li>
                    <li><a href="#"class="text-white font-italic">On Order Design</a></li>
                    <li><a href="#"class="text-white font-italic">Continentals Design</a></li>
                    <li><a href="#"class="text-white font-italic">Item By Gender</a></li>
                    <li><a href="#"class="text-white font-italic">24/7 Servies </a></li>
                  </ul>
                </div>
                <div class="col col-md-3 ">
                    <h5>Our Address</h5>
                    <address>
                  121, Clear Water Bay Road<br>
                  Clear Water Bay, Kowloon<br>
                  HONG KONG<br>
                  <i class="fa fa-phone fa-lg "></i>: +852 1234 5678<br>
                  <i class="fa fa-fax fa-lg "></i>: +852 8765 4321<br>
                  <i class="fa fa-envelope fa-lg "></i>: <a href="mailto:hrkuch@gmail.com "class="text-white">hr@gmail.com </a>
               </address>
                </div>
                <div class="col col-md-3 ">
                    <h5>Location</h5>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d226.3806012017019!2d73.97506534427651!3d24.792384588844125!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3968778486c725fd%3A0xebaa29731626ffc1!2sBALAJI%20JEWELLERS!5e0!3m2!1sen!2sin!4v1593876980709!5m2!1sen!2sin" width="300" height="300" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                </div>
            </div>
        </div>
	</footer>
	
		<script src="js/jquery.js"></script>
		<script src="js/bootstrap.min.js"></script>
</body>
</html>