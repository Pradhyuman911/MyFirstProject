<?php
	include("adminhome.php");
?>

	<style type="text/css">
.abc{
	
		background-color:whitesmoke;
		padding: 50px;
		width: 200px;
		height:1000px;
}
	</style>

				
				<div class="col-md-1"></div>
				<div class="col-md-8 abc"id="main-content">
				<center><h3>Category Update Details</h3></center> 
	<?php
	
	$con=mysqli_connect("localhost","root","","jwellery");
	$r= mysqli_query($con,"select * from catimg");
	$count=0;
	
	echo "<table border='1'align='center'cellspacing=0cellpadding=10>";
	echo "<tr><th>Id</th>
		<th>Jwellery Type</th>
		<th>Jwellery Name</th>
		<th>Jwellery Price </th>
		<th>Jwellery Weight</th>
		<th>Update</th>
		</tr>";
	while($row=mysqli_fetch_array($r))
	{
		$id=$row[0];
		$count++;
		echo "<tr><td>",$count,"</td>";
		echo "<td>",$row[1],"</td>";
		echo "<td>",$row[2],"</td>";
		echo "<td>",$row[3],"</td>";
		echo "<td>",$row[4],"</td>
		
		<td><a href='catupdate2.php?id=$id'>Update</a></td></tr>";
	}
?>

</table>
</div>
</div>
</body>
</html>