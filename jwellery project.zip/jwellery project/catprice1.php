<?php
	$price=$_POST['price'];
	
	
	
	$con=mysqli_connect('localhost','root','','jwellery');
	$s="INSERT INTO `catprice`( `price`) VALUES ('$price')";
	$r=mysqli_query($con,$s);
	if($r)
		header("location:catprice.php");
	else
		echo "not inserted";
?>