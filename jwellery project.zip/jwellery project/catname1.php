<?php
	$name=$_POST['name'];
	
	
	
	$con=mysqli_connect('localhost','root','','jwellery');
	$s="INSERT INTO `catname`( `name`) VALUES ('$name')";
	$r=mysqli_query($con,$s);
	if($r)
		header("location:catname.php");
	else
		echo "not inserted";
?>