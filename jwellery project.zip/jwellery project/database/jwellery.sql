-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2020 at 06:36 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jwellery`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `type`) VALUES
(8, 'Gold'),
(9, 'silver'),
(10, 'Diamond');

-- --------------------------------------------------------

--
-- Table structure for table `catimg`
--

CREATE TABLE `catimg` (
  `id` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `weight` varchar(11) NOT NULL,
  `img` varchar(123) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `catimg`
--

INSERT INTO `catimg` (`id`, `type`, `name`, `price`, `weight`, `img`) VALUES
(1, 'Diamond', 'Ring', 23, '233', 'bangles2.jpg'),
(3, 'silver', 'bangles', 23, '233', 'bangles2.jpg'),
(8, 'Diamond', 'Ring', 23333, '500 gm', 'ring4.jpg'),
(9, 'Gold', 'baraclet', 23333, '500gm', 'braclet1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `catname`
--

CREATE TABLE `catname` (
  `id` int(20) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `catname`
--

INSERT INTO `catname` (`id`, `name`) VALUES
(1, 'bangles'),
(2, 'anklet'),
(3, 'Ring'),
(4, 'baraclet'),
(5, 'Necklace');

-- --------------------------------------------------------

--
-- Table structure for table `catprice`
--

CREATE TABLE `catprice` (
  `id` int(100) NOT NULL,
  `price` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `catprice`
--

INSERT INTO `catprice` (`id`, `price`) VALUES
(1, '23'),
(2, '23333');

-- --------------------------------------------------------

--
-- Table structure for table `catweight`
--

CREATE TABLE `catweight` (
  `id` int(11) NOT NULL,
  `weight` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `catweight`
--

INSERT INTO `catweight` (`id`, `weight`) VALUES
(1, '233'),
(2, '500gm'),
(3, '500 gm');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `cname` varchar(25) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `pincode` int(20) NOT NULL,
  `city` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cnum1` int(15) NOT NULL,
  `cnum2` int(15) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `cname`, `fname`, `address`, `pincode`, `city`, `email`, `cnum1`, `cnum2`, `password`) VALUES
(8, 'malisha', 'dharmendra', 'maheshwari', 122434, 'jaipur', 'mali@gmail.com', 2147483647, 23455, 'malisha@123');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `password`, `email`) VALUES
(1, 'malisha', 'malisha@123', 'malisha@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catimg`
--
ALTER TABLE `catimg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catname`
--
ALTER TABLE `catname`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catprice`
--
ALTER TABLE `catprice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catweight`
--
ALTER TABLE `catweight`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `catimg`
--
ALTER TABLE `catimg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `catname`
--
ALTER TABLE `catname`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `catprice`
--
ALTER TABLE `catprice`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `catweight`
--
ALTER TABLE `catweight`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
