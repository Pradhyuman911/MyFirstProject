<?php
	include("adminhome.php");
?>
	
	<style type="text/css">
.abc{
	
		background-color:light;
		padding: 50px;
		width: 250px;
		height:650px;
}
img{
		padding:10px;
		
	}
	</style>

				
				<div class="col-md-1"></div>
				<div class="col-md-8 abc"id="main-content">
			
				<center><strong><h3>View Gallery</h3></strong></center>
					
				<br>
	<?php
	$con = mysqli_connect("localhost","root","","jwellery");
	$sql = "SELECT  * FROM `catimg`";
	$count = 0;
	
	$rs = mysqli_query ($con,$sql);
	while ($row = mysqli_fetch_assoc($rs))
	{
		$id=$row["id"];
		$name=$row["name"];
		$price=$row["price"];
		$count ++;
		$photo ="jwellpics/".$row ["img"];
		echo "<img src='$photo' alt='hello' title='$name,$price' height=200 width=200>";
		//echo "<td><a href='deletephoto.php?id=$id'>Delete</a></td></tr>";
		
	}
	
?>
</div>
</div>
<>