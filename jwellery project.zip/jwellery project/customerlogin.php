<html>
<head>

		<title>Sign In</title>
		<link rel="stylesheet"href="css/bootstrap.min.css">
		<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	</head>
	<style type="text/css">
	#side_bar{
		bg-primary;
		padding: 50px;
		width: 200px;
		height:550px;
	}
	</style>
<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="">Shivam Jwellers</a>
			</div>
			<ul class="nav navbar-nav navbar-right">
				
				<li class="nav-item">
					<a class="nav-link"href="admin.php">Admin Login</a>
				</li>
			</ul>
		</div>
	</nav>
	<div class="row">
	 <div class="col-md-3"></div>
	     <div class="col-md-6" id="side_bar">
	<center><br><br>
			<h3>Customer Sign In</h3><br></center>
				<form action="customerlogin1.php"method="post">
				Customer Name<br>
					<input type="text" name="cname" class="form-control"required>
				 Father's Name<br>
					<input type="text" name="fname" class="form-control"required>
				Address<br>
					<textarea rows=3 cols=5 name="address" class="form-control"required></textarea>
				Mobile Number<br>
					<input type="text" name="cnum1" class="form-control"required>
					<input type="text" name="cnum2" class="form-control"required>
				pincode<br>
					<input type="text" name="pincode" class="form-control"required>
				City<br>
				<label for="state"></label>
		<select id="state"name="state" class="form-control">
		<optgroup label="Rajsthan">
		<option value="jaipur">Jaipur</option>
		<option value="Udaipur">Udaipur</option>
		<option value="Jaisalmer">Jaisalmer</option>
		</optgroup>
		<optgroup label="Gujart">
		<option value="Kach">Kach</option>
		<option value="Dman">Dman</option>
		<option value="Deev">Deev</option>
		</optgroup>
	</select><br>
				Email Id<br>
					<input type="email" name="email" class="form-control"required>
				Password<br>
					<input type="password" name="password" class="form-control"required>
				<center><button  type="submit" class="btn btn-primary">Sign In</button>
				</center>
	</form>
	<div class="col-md-3">
	</div>
</body>
</html>




		
					
			
		
					
		
					
		
		
		
			
