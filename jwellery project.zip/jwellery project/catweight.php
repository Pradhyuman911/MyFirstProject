<?php
	include("adminhome.php");
?>
	
	<style type="text/css">
.abc{
	
		background-color:light;
		padding: 50px;
		width: 250px;
		height:1000px;
}
	</style>

				
				<div class="col-md-1"></div>
				<div class="col-md-8 abc"id="main-content">
				<form action="catweight1.php"method="post">
				<center><h3>Category</h3></center>
					
				Jwellery Weight <br>
					<input type="text" name="weight" class="form-control">
				
				<center><button  type="submit" class="btn btn-primary">insert</button>
				</center>
			</form>
		</div>
		</div>
	</body>
	</html>
		