<html>
	<head>
		<title>Customer Home</title>
		<link rel="stylesheet"href="css/bootstrap.min.css">
		<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	</head>
	<style type="text/css">
	#side_bar{
		background-color:yellow;
		padding: 50px;
		width: 200px;
		height:550px;
	}
	.abc
	{
		input[type=text]:focus{
			width:25%;
			background-image:url('searchicon.png');
			background-repeat:no-repeat;
			background-position:10px 10px;
		}
	}
	img{
		padding:10px;
		
	}
	
	</style>
<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-info">
		<div class="container-fluid">
			<div class="navbar-header">
			<img src="jwellpics/shiva.jpg."style="width:80px;height:80px">
				<a class="navbar-brand" href="customerhome.php"><h5>Shivam Jwellers</h5></a>
				
			</div>
			<ul class="nav navbar-nav navbar-right">
				<li class="nav-item abc" >
				<center>	<input type="text"name="search"placeholder="search...."></center>
				</li>
				<li class="nav-item">
					<a class="nav-link"href="">Gallery</a>
				</li>
				<li class="nav-item">
					<a class="nav-link"href="contactus.php">Contact Us</a>
				</li>
				<li class="nav-item">
					<a class="nav-link"href="">Cart</a>
				</li>
				<li class="nav-item">
					<a class="nav-link"href="">Logout</a>
				</li>
				
				
			</ul>
		</div>
	</nav>
	
	<div class="row">
	<div class="col-md-4"></div>
	<div class="col-md-8 abc"id="main-content">
	
	<?php
	$con = mysqli_connect("localhost","root","","jwellery");
	$sql = "SELECT  * FROM `catimg`";
	$count = 0;
	
	$rs = mysqli_query ($con,$sql);
	while ($row = mysqli_fetch_assoc($rs))
	{
		$id=$row["id"];
		$name=$row["name"];
		$price=$row["price"];
		$count ++;
		$photo ="jwellpics/".$row ["img"];
		echo "<img src='$photo' alt='hello' title='$name,$price' height=200 width=200>";
		//echo "<td><a href='deletephoto.php?id=$id'>Delete</a></td></tr>";
		
	}
	
?>
<div class="col-md-3">
</div>
</div>
</div>		
			

</body>
</html>