<?php
	$type=$_POST['type'];
	
	
	
	$con=mysqli_connect('localhost','root','','jwellery');
	$s="INSERT INTO `category`( `type`) VALUES ('$type')";
	$r=mysqli_query($con,$s);
	if($r)
		header("location:usercat.php");
	else
		echo "not inserted";
?>