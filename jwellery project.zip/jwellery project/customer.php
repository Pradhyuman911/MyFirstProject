	<?php
	
			$con=mysqli_connect("localhost","root","","jwellery");
				$query="select * from customer where email='$_POST[email]'";
				$rs=mysqli_query($con,$query);
						while($row=mysqli_fetch_assoc($rs))
						{
							if($row['email']==$_POST['email'])
							{
								if($row['password']==$_POST['password'])
								{
									header("location:customerhome.php");
									
								}
								else
								{
									echo "wrong password";
								}
							}
							else
							{
								echo "wrong email id";
							}
						}
				
			?>
