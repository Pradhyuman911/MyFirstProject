<?php
	$cname=$_POST["cname"];
	$fname=$_POST["fname"];
	$address=$_POST["address"];
	$pincode=$_POST["pincode"];
	$cnum1=$_POST["cnum1"];
	$cnum2=$_POST["cnum2"];
	$city=$_POST["state"];	
	$email=$_POST["email"];
	$password=$_POST["password"];
	
	
	$con=mysqli_connect('localhost','root','','jwellery');
	$s="INSERT INTO `customer`(`cname`, `fname`, `address`, `pincode`, `city`, `email`, `cnum1`, `cnum2`, `password`) VALUES ('$cname','$fname','$address','$pincode','$city','$email','$cnum1','$cnum2','$password')";
	$r=mysqli_query($con,$s);
	if($r)
		
		header("location:login.php");
	else
		echo "not inserted";
?>