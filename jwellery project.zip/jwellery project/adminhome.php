<html>
	<head>
		<title>Admin Home</title>
		<link rel="stylesheet"href="css/bootstrap.min.css">
		<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	</head>
	<style type="text/css">
	#side_bar{
		background-color:yellow;
		padding: 50px;
		width: 200px;
		height:1000px;
	}
	
	
	<!--.abc
	{
		input[type=text]:focus{
			width:25%;
			background-image:url('searchicon.png');
			background-repeat:no-repeat;
			background-position:10px 10px;
		}
	}-->
	
	</style>
<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-info">
		<div class="container-fluid">
			<div class="navbar-header">
			<img src="jwellpics/shiva.jpg."style="width:80px;height:80px">
				<a class="navbar-brand" href="adminhome.php"><h5>Shivam Jwellers</h5></a>
			</div>
			<ul class="nav navbar-nav navbar-right">
				
				<li class="nav-item">
					<a class="nav-link"href="logout.php">Logout</a>
				</li>
				
				<li class="nav-item">
					<a class="nav-link"href="viewgallery.php">Gallery</a>
				</li>
				<!--<li class="nav-item abc" >
				<center>	<input type="text"name="search"placeholder="search...."></center>
				</li>-->
			</ul>
		</div>
	</nav>
		<div class="row">
			<div class="col-md-3"id="side_bar">
				<h3>Categories</h3>
				<ul>
				<li><a href="usercat.php">JWellery Type</a></li>
				<li><a href="catname.php">JWellery Name</a></li>
				<li><a href="catprice.php">JWellery Price</a></li>
				<li><a href="catweight.php">JWellery Weight</a></li>
				<li><a href="addimgcat.php">Add Image</a></li>
				<li><a href="catupdate1.php">Update</a></li>
					<li><a href="catdlt.php">Delete</a></li>
					<li><a href="catview.php">View</a></li>
				</ul>
				<h3>Users</h3>
				<ul>
					
					<li><a href="userupdate.php">Update</a></li>
					<li><a href="userdlt.php">Delete</a></li>
					<li><a href="userview.php">View</a></li>
				</ul>
				<h3>Order Details</h3>
				<ul>
					<li><a href="">Update</a></li>
					<li><a href="">Delete</a></li>
					<li><a href="">View</a></li>
				</ul>
</div>
<!--</div>
</body>
</html>-->

	

