<?php
	$id=$_POST["id"];
	$type=$_POST["type"];
	$name=$_POST["name"];
	$price=$_POST["price"];
	$weight=$_POST["weight"];
	
	
	
	
	$con=mysqli_connect("localhost","root","","jwellery");
	$s="UPDATE `catimg` SET `type`='$type',`name`='$name',`price`='$price',`weight`='$weight' WHERE id='$id'";
	$r=mysqli_query($con,$s);
	echo $s;
	if($r)
		//echo "record update";
		header("location:catupdate1.php");
	else
		echo "record can't be update";
	?>