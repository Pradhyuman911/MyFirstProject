<?php
	$id=$_POST["id"];
	$cname=$_POST["cname"];
	$fname=$_POST["fname"];
	$address=$_POST["address"];
	$pincode=$_POST["pincode"];
	$cnum1=$_POST["cnum1"];
	$cnum2=$_POST["cnum2"];
	$city=$_POST["state"];	
	$email=$_POST["email"];
	$password=$_POST["password"];
	
	
	$con=mysqli_connect("localhost","root","","jwellery");
	$s="UPDATE `customer` SET `cname`='$cname',`fname`='$fname',`address`='$address',`pincode`='$pincode',`city`='$city',`email`='$email',`cnum1`='$cnum1',`cnum2`='$cnum2',`password`='$password' WHERE id='$id'";
	$r=mysqli_query($con,$s);
	if($r)
		
		header("location:userupdate.php");
	else
		echo "record can't be update";
	?>