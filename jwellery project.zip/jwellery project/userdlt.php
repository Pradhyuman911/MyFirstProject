<?php
	include("adminhome.php");
?>

	<style type="text/css">
.abc{
	
		background-color:whitesmoke;
		padding: 50px;
		width: 200px;
		height:450px;
}
	</style>

				
				<div class="col-md-1"></div>
				<div class="col-md-8 abc"id="main-content">
				<center><h3>Customer delete Details</h3></center> 
	<?php
	
	$con=mysqli_connect("localhost","root","","jwellery");
	$r= mysqli_query($con,"select * from customer");
	$count=0;
	
	echo "<table border='1'align='center'cellspacing=0cellpadding=10>";
	echo "<tr><th>Id</th>
		<th>Coustmer Name</th>
		<th>Father's Name</th>
		<th>Address</th>
		<th>Pincode</th>
		<th>City</th>
		<th>Email</th>
		<th>Number1</th>
		<th>Number2</th>
		<th>Password</th>
		<th>Delete</th>
		</tr>";
	while($row=mysqli_fetch_array($r))
	{
		$id=$row[0];
		$count++;
		echo "<tr><td>",$count,"</td>";
		echo "<td>",$row[1],"</td>";
		echo "<td>",$row[2],"</td>";
		echo "<td>",$row[3],"</td>";
		echo "<td>",$row[4],"</td>";
		echo "<td>",$row[5],"</td>";
		echo "<td>",$row[6],"</td>";
		echo "<td>",$row[7],"</td>";
		echo "<td>",$row[8],"</td>";
		echo "<td>",$row[9],"</td>
		<td><a href='userdlt1.php?id=$id'>Delete</a></td></tr>";
	}
?>

</table>
</div>
</div>
</body>
</html>