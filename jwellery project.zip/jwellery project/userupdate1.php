<?php
	include("adminhome.php");
?>
	
	<style type="text/css">
.abc{
	
		background-color:light;
		padding: 50px;
		width: 250px;
		height:650px;
}
	</style>

				
				<div class="col-md-1"></div>
				<div class="col-md-8 abc"id="main-content">
				<form action="userupdate2.php"method="post">
				<center><h3>Customer Update Details</h3></center>
<?php
	$id=$_GET['id'];
	
	$con=mysqli_connect("localhost","root","","jwellery");
	$sql="select * from customer where id='$id'";
	$rs=mysqli_query($con,$sql);
		while($row=mysqli_fetch_row($rs))
		{
			$id=$row[0];
			$cname=$row[1];
			$fname=$row[2];
			$address=$row[3];
			$pincode=$row[4];
			$city=$row[5];
			$email=$row[6];
			$cnum1=$row[7];
			$cnum2=$row[8];
			$password=$row[9];
	
		}
?>

<input type="hidden"value="<?php echo $id;?>"name="id">
		
				Customer Name<br>
					<input type="text" name="cname"value="<?php echo $cname?>" class="form-control"required>
				 Father's Name<br>
					<input type="text" name="fname" value="<?php echo $fname?>"class="form-control"required>
				Address<br>
					<textarea rows=3 cols=5 name="address" class="form-control"required><?php echo $address?></textarea>
				Mobile Number<br>
					<input type="text" name="cnum1"value="<?php echo $cnum1?>" class="form-control"required>
					<input type="text" name="cnum2" value="<?php echo $cnum2?>"class="form-control"required>
				pincode<br>
					<input type="text" name="pincode"value="<?php echo $pincode?>" class="form-control"required>
				City<br>
				<label for="state"></label>
		<select id="state"name="state" value="<?php echo $city?>"class="form-control">
		<optgroup label="Rajsthan">
		<option value="jaipur">Jaipur</option>
		<option value="Udaipur">Udaipur</option>
		<option value="Jaisalmer">Jaisalmer</option>
		</optgroup>
		<optgroup label="Gujart">
		<option value="Kach">Kach</option>
		<option value="Dman">Dman</option>
		<option value="Deev">Deev</option>
		</optgroup>
	</select><br>
				Email Id<br>
					<input type="email" name="email"value="<?php echo $email?>" class="form-control"required>
				Password<br>
					<input type="password" name="password"value="<?php echo $password?>" class="form-control"required>
				<center><button  type="submit" class="btn btn-primary">Submit</button>
				</center>
	
	<div class="col-md-3">
	</div>
	
</table>
</form>
	
</div>
</div>
</body>
</html>