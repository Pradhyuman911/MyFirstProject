<?php
	include("adminhome.php");
?>

	<style type="text/css">
.abc{
	
		background-color:white;
		padding: 50px;
		width: 200px;
		height:1000px;
}
	</style>

				
				<div class="col-md-1"></div>
				<div class="col-md-8 abc"id="main-content">
				<form action="catupdate2.php"method="post">
				<center><h3>Category View Details</h3></center> 
	<?php
	
	$con=mysqli_connect("localhost","root","","jwellery");
	$r= mysqli_query($con,"select * from catimg");
	$count=0;
	
	echo "<table border='1'align='center'cellspacing=0cellpadding=10>";
	echo "<tr><th>Id</th>
	<th>Jwellery Image</th>
		  <th>Jwellery type</th>
		<th>Jwellery Name</th>
		<th>Jwellery Price</th>
		<th>Jwellery Weight</th>
		
		
		
		</tr>";
	while($row=mysqli_fetch_assoc($r))
	{
		$count++;
		echo "<tr><td>",$count,"</td>";
		echo "<td>";
		
		$photo="jwellpics/".$row["img"];
		echo "<a href='$photo' download>";
		echo "<img src='$photo' height=200 width=200><br><br>";
		echo "</a>";
		echo "<td>",$row["type"],"</td>";
		echo "<td>",$row["name"],"</td>";
		echo "<td>",$row["price"],"</td>";
		echo "<td>",$row["weight"],"</td>";
		echo "</td>";

			echo "</tr>";
	}
?>

</table>
</div>
</div>
</body>
</html>