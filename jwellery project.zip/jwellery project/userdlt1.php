<?php
	$id=$_GET['id'];
	
	$con=mysqli_connect("localhost","root","","jwellery");
	$sql="delete from customer where id='$id'";
	$rs=mysqli_query($con,$sql);
		if($rs)
			header("location:userdlt.php");
		else
			echo "record not delete";
?>