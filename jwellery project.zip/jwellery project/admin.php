<html>
	<head>
		<title>Login Page</title>
		<link rel="stylesheet"href="css/bootstrap.min.css">
		<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	</head>
	<style type="text/css">
	#side_bar{
		background-color:whitesmoke;
		padding: 50px;
		width: 200px;
		height:550px;
	}
	</style>
<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="">Shivam Jwellers</a>
			</div>
			<ul class="nav navbar-nav navbar-right">
				
				<li class="nav-item">
					<a class="nav-link"href="login.php">Admin Logout</a>
				</li>
			</ul>
		</div>
	</nav>
<div class="row">
	 <div class="col-md-3"></div>
	     <div class="col-md-6" id="side_bar">
	<center><br><br>
			<h3>Admin Login Page</h3><br></center>
				<form action="adminhome.php"method="post">
					Email:<input type="text"name="email"class="form-control"required><br><br>
					Password:<input type="password"name="password"class="form-control"required><br><br>
					<center><button  type="submit" class="btn btn-primary">login</button>	
				</form>
					</center>
					
				
		</div>
		<div class="col-md-3"></div>
	</div>
</body>
</html>
			<?php
				if(isset($_POST ['submit']))
				{
						$con=mysqli_connect("localhost","root","","jwellery");
						$query="select * from login where email='$_POST[email]'";
						$rs=mysqli_query($con,$query);
						while($row=mysqli_fetch_assoc($rs))
						{
							if($row['email']==$_POST['email'])
							{
								if($row['password']==$_POST['password'])
								{
									
									header("location:adminhome.php");
								}
								else
								{
									echo "wrong password";
								}
							
							}
							else
							{
								echo "wrong email";
							}
						}
				}
			?>
		
