<html>
	<head>
		<title>Admin Home</title>
		<link rel="stylesheet"href="css/bootstrap.min.css">
		<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	</head>
	<style type="text/css">
	#side_bar{
		background-color:whitesmoke;
		padding: 50px;
		width: 200px;
		height:450px;
	}
	</style>
<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="">Shivam Jwellers</a>
			</div>
			<ul class="nav navbar-nav navbar-right">
				<li class="nav-item">
					<a class="nav-link"href="">Home</a>
				</li>
				<li class="nav-item">
					<a class="nav-link"href="">Logout</a>
				</li>
				<li class="nav-item">
					<a class="nav-link"href="">Profile</a>
				</li>
			</ul>
		</div>
	</nav>
</body>
</html>