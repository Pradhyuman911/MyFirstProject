<?php
	include("adminhome.php");
?>
	
	<style type="text/css">
.abc{
	
		background-color:light;
		padding: 50px;
		width: 250px;
		height:650px;
}
	</style>

				
				<div class="col-md-1"></div>
				<div class="col-md-8 abc"id="main-content">
				<form action="catname1.php"method="post">
				<center><h3>Category</h3></center>
					
				Jwellery Name <br>
					<input type="text" name="name" class="form-control">
				
				<center><button  type="submit" class="btn btn-primary">insert</button>
				</center>
			</form>
		</div>
		</div>
	</body>
	</html>
		