<html>
<head>
	<title></title>
	<link rel="stylesheet"href="css/bootstrap.min.css">
		<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	</head>
	<style type="text/css">
	.abc{
		background-color:whitesmoke;
		padding: 50px;
		width: 200px;
		height:450px;
	}
	</style>
</head>

<body>
<div>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 abc" >
				<h2>User Login</h2>
				<form action="customer.php"method="post">
					<div class="form-group">
						<label>username</label>
							<input type="text"name="user"class="form-control">
					</div>
					<div class="form-group">
						<label> password </label>
							<input type="password"name="password"class="form-control">
					</div>
						<button class="btn btn-primary">login</button>
				</form>
			</div>
		</div>
	</div>
</div>

	<div class="container">
		<div class="row">
			<div class="col-lg-6 abc">
				<h2>Sign In</h2>
				<form action=""method="post">
					<div class="form-group">
						<label>First Name</label>
							<input type="text"name="fname"class="form-control">
					</div>
					<div class="form-group">
						<label>Last Name</label>
							<input type="text"name="lname"class="form-control">
					</div>
					<div class="form-group">
						<label> Email </label>
							<input type="email"name="email"class="form-control">
					</div>
					<div class="form-group">
						<label> password </label>
							<input type="password"name="password"class="form-control">
					</div>
					<div class="form-group">
						<label> Mobile Number </label>
							<input type="text"name="number"class="form-control">
					</div>
					
						<button class="bt btn-primary">sign in</button>
				</form>
			</div>
		</div>
	</div>
</body>
</html>