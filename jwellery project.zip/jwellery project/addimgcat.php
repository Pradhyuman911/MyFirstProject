
<?php
	include("adminhome.php");
?>
	
	<style type="text/css">
.abc{
	
		background-color:whitesmoke;
		padding: 50px;
		width: 250px;
		height:1000px;
}
	</style>

				
				<div class="col-md-1"></div>
				<div class="col-md-8 abc"id="main-content">
				<form action="addimgcat1.php" method="post" enctype="multipart/form-data">
				<center><h3>Jwellery Details</h3></center>
				Category
				<select name='type'class="form-control">

						<option>select</option>
						<?php
								$con = mysqli_connect("localhost","root","","jwellery");
								$sql = "SELECT * FROM `category` ";
								$count = 0;
								$rs = mysqli_query ($con,$sql);
								while ($row = mysqli_fetch_assoc($rs))
								{
									$type = $row['type'];
									echo "<option>".$type."</option>";
								}
						
						?>
					</select>
					<br>
					 Name<br>
					<select name='name'class="form-control">

						<option>select</option>
						<?php
								$con = mysqli_connect("localhost","root","","jwellery");
								$sql = "SELECT * FROM `catname`";
								$count = 0;
								$rs = mysqli_query ($con,$sql);
								while ($row = mysqli_fetch_assoc($rs))
								{
									$name = $row['name'];
									echo "<option>".$name."</option>";
								}
						
						?>
					</select>
					<br>
					Price<br>
					<select name='price'class="form-control">

						<option>select</option>
						<?php
								$con = mysqli_connect("localhost","root","","jwellery");
								$sql = "SELECT * FROM `catprice` ";
								$count = 0;
								$rs = mysqli_query ($con,$sql);
								while ($row = mysqli_fetch_assoc($rs))
								{
									$price = $row['price'];
									echo "<option>".$price."</option>";
								}
						
						?>
					</select>
					<br>
					Weight<br>
					<select name='weight'class="form-control">

						<option>select</option>
						<?php
								$con = mysqli_connect("localhost","root","","jwellery");
								$sql = "SELECT * FROM `catweight` ";
								$count = 0;
								$rs = mysqli_query ($con,$sql);
								while ($row = mysqli_fetch_assoc($rs))
								{
									$weight = $row['weight'];
									echo "<option>".$weight."</option>";
								}
						
						?>
					</select><br>
					 Choose Photo<br>
					 <input type="file"name="img"class="form-control"><br>
					 <center><button  type="submit" class="btn btn-primary">Save</button>
				</center>
					
					</select>
						</form>
		</div>
		</div>
	</body>
	</html>
				