<?php
	$id=$_GET['id'];
	
	$con=mysqli_connect("localhost","root","","jwellery");
	$sql="DELETE FROM `catimg` WHERE id='$id'";
	$rs=mysqli_query($con,$sql);
		if($rs)
			header("location:catdlt.php");
		else
			echo "record not delete";
?>