<?php
	include("adminhome.php");
?>
	
	<style type="text/css">
.abc{
	
		background-color:light;
		padding: 50px;
		width: 250px;
		height:650px;
}
	</style>

				
				<div class="col-md-1"></div>
				<div class="col-md-8 abc"id="main-content">
				<form action="catupdate3.php"method="post">
				<center><h3>Category Update Details</h3></center>
<?php
	$id=$_GET['id'];
	
	$con=mysqli_connect("localhost","root","","jwellery");
	$sql="select * from catimg where id='$id'";
	$rs=mysqli_query($con,$sql);
		while($row=mysqli_fetch_row($rs))
		{
			$id=$row[0];
			$type=$row[1];
			$name=$row[2];
			$price=$row[3];
			$weight=$row[4];
			
			
	
		}
?>			Category
	<input type="hidden"value="<?php echo $id;?>"name="id">
				<select name='type'class="form-control">

						<option><?php echo $type?></option>
						<?php
								$con = mysqli_connect("localhost","root","","jwellery");
								$sql = "SELECT * FROM `category` ";
								$count = 0;
								$rs = mysqli_query ($con,$sql);
								while ($row = mysqli_fetch_assoc($rs))
								{
									$type = $row['type'];
									echo "<option>".$type."</option>";
								}
						
						?>
					</select>
					<br>
					 Name<br>
					<select name='name'class="form-control">

						<option><?php echo $name?></option>
						<?php
								$con = mysqli_connect("localhost","root","","jwellery");
								$sql = "SELECT * FROM `catname`";
								$count = 0;
								$rs = mysqli_query ($con,$sql);
								while ($row = mysqli_fetch_assoc($rs))
								{
									$name = $row['name'];
									echo "<option>".$name."</option>";
								}
						
						?>
					</select>
					<br>
					Price<br>
					<select name='price'class="form-control">

						<option><?php echo $price?></option>
						<?php
								$con = mysqli_connect("localhost","root","","jwellery");
								$sql = "SELECT * FROM `catprice` ";
								$count = 0;
								$rs = mysqli_query ($con,$sql);
								while ($row = mysqli_fetch_assoc($rs))
								{
									$price = $row['price'];
									echo "<option>".$price."</option>";
								}
						
						?>
					</select>Weight<br>
					<select name='weight'class="form-control">

						<option><?php echo $weight?></option>
						<?php
								$con = mysqli_connect("localhost","root","","jwellery");
								$sql = "SELECT * FROM `catweight` ";
								$count = 0;
								$rs = mysqli_query ($con,$sql);
								while ($row = mysqli_fetch_assoc($rs))
								{
									$weight = $row['weight'];
									echo "<option>".$weight."</option>";
								}
						
						?>
					</select><br>
					 
					 <center><button  type="submit" class="btn btn-primary">Save</button>
				</center>

	
		
			<!--	Jwellery Type<br>
					<input type="file" name="image"value="<?php echo $image?>" class="form-control">
				 Jwellery Name<br>
					<input type="text" name="name" value="<?php echo $name?>"class="form-control">
				Jwellery Weight<br>
					<input type="text" name="weight"value="<?php echo $weight?>" class="form-control">
				Jwellery Price<br>
					<input type="text" name="price"value="<?php echo $price?>" class="form-control">
				<center><button  type="submit" class="btn btn-primary">submit</button>
				</center>-->
	
	<div class="col-md-3">
	</div>
	
</table>
</form>
	
</div>
</div>
</body>
</html>