<?php
	$weight=$_POST['weight'];
	
	
	
	$con=mysqli_connect('localhost','root','','jwellery');
	$s="INSERT INTO `catweight`( `weight`) VALUES ('$weight')";
	$r=mysqli_query($con,$s);
	if($r)
		header("location:catweight.php");
	else
		echo "not inserted";
?>