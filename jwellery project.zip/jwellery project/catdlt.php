<?php
	include("adminhome.php");
?>

	<style type="text/css">
.abc{
	
		background-color:whitesmoke;
		padding: 50px;
		width: 200px;
		height:1000px;
}
	</style>

				
				<div class="col-md-1"></div>
				<div class="col-md-8 abc"id="main-content">
				<center><h3>Category delete Details</h3></center> 
	<?php
	
	$con=mysqli_connect("localhost","root","","jwellery");
	$r= mysqli_query($con,"select * from catimg");
	$count=0;
	
	echo "<table border='1'align='center'cellspacing=0cellpadding=0>";
	echo "<tr><th>Id</th>
		<th>Jwellery type</th>
		<th>Jwellery Name</th>
		<th>Jwellery Price</th>
		<th>Jwellery Weight</th>
		<th>Jwellery Image</th>
		<th>Delete</th>
		</tr>";
	while($row=mysqli_fetch_array($r))
	{
		$id=$row[0];
		$count++;
		echo "<tr><td>",$count,"</td>";
		echo "<td>",$row[1],"</td>";
		echo "<td>",$row[2],"</td>";
		echo "<td>",$row[3],"</td>";
		echo "<td>",$row[4],"</td>";
		echo "<td>",$row[5],"</td>
		
		<td><a href='catdlt1.php?id=$id'>Delete</a></td></tr>";
	}
?>

</table>
</div>
</div>
</body>
</html>