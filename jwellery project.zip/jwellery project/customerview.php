<?php
	include("customerhome.php");
?>

	<style type="text/css">
.mcq{
	
		background-color:whitesmoke;
		padding: 50px;
		width: 200px;
		height:450px;
}
	</style>

				
				<div class="col-md-1"></div>
				<div class="col-md-8 mcq"id="main-content">
				<form action="customerview.php"method="post">
				<center><h3>Category View Details</h3></center> 
	<?php
	
	$con=mysqli_connect("localhost","root","","jwellery");
	$r= mysqli_query($con,"select * from category");
	$count=0;
	
	echo "<table border='1'align='center'cellspacing=0cellpadding=10>";
	echo "<tr><th>Id</th>
		  <th>Jwellery Image</th>
		<th>Jwellery Name</th>
		<th>Jwellery Weight</th>
		<th>Jwellery Price</th>
		
		</tr>";
	while($row=mysqli_fetch_array($r))
	{
		$count++;
		echo "<tr><td>",$count,"</td>";
		echo "<td>";
		$photo="jwellery_pics/".$row[1];
		echo "<a href='$photo' download>";
		echo "<img src='$photo' height=200 width=200><br><br>";
		echo "</a>";
		echo "</td>";
		echo "<td>",$row[2],"</td>";
		echo "<td>",$row[3],"</td>";
		echo "<td>",$row[4],"</td>";

			echo "</tr>";
	}
?>

</table>
<!--</div>-->
</div>
</body>
</html>