-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2020 at 08:30 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ro project`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(5, 'kent ro'),
(8, 'pureit'),
(9, 'Aqua'),
(10, 'Whirpool'),
(11, 'Whirlpool'),
(12, 'LG');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `id` int(11) NOT NULL,
  `pname` varchar(20) NOT NULL,
  `price` varchar(20) NOT NULL,
  `img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`id`, `pname`, `price`, `img`) VALUES
(6, 'kent ro', '5000', 'purifier.jpg'),
(7, 'pureit', '10000', 'purifier.jpg'),
(8, 'Aqua', '7000', 'ro3.jpg'),
(9, 'Whirlpool', '9000', 'images (3).jpg'),
(10, 'LG', '12000', 'ro.jpg'),
(11, 'Aqua', '8000', 'images (4).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `password`) VALUES
(1, 'Shreya', 'shreya@gmail.com', 'shreya@123');

-- --------------------------------------------------------

--
-- Table structure for table `priceins`
--

CREATE TABLE `priceins` (
  `id` int(11) NOT NULL,
  `price` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `priceins`
--

INSERT INTO `priceins` (`id`, `price`) VALUES
(1, '5000'),
(2, '10000'),
(3, '7000'),
(4, '8000'),
(5, '9000'),
(6, '11000'),
(7, '12000');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `uname` text NOT NULL,
  `fname` text NOT NULL,
  `mnum1` int(15) NOT NULL,
  `mnum2` int(15) NOT NULL,
  `email` varchar(25) NOT NULL,
  `address` varchar(100) NOT NULL,
  `pincode` int(15) NOT NULL,
  `city` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `uname`, `fname`, `mnum1`, `mnum2`, `email`, `address`, `pincode`, `city`, `password`) VALUES
(1, 'siya', 'abcd', 123456, 234567, 'siya@gmail.com', 'dfdrdakewe', 345657, 'udaipur', 'siya@123'),
(3, 'eretsrtjd', 'E,HGFLN,CL', 1234567, 23456, 'malishasoni@gmail.com', 'tryjhhg', 234567, 'Udaipur', '234567'),
(4, 'Siya', 'hgfvddd', 0, 0, 'malishasoni@gmail.com', 'swetrtykgfbdv', 0, 'Udaipur', '12345678'),
(5, 'shreya', 'dsdfhg', 0, 0, 'vjshreya@gmial.cm', '', 0, 'Udaipur', '123456'),
(6, 'shreya', 'sawj', 34567, 0, 'shreya@gmail.com', 'eghgjkhf', 3456789, 'Udaipur', 'shreya@123'),
(8, 'eretsrtjd', 'fg', 0, 0, 'vjshreya@gmial.cm', '', 0, 'Udaipur', '3456789'),
(9, 'shreya', 'erth', 0, 0, 'shreya@gmail.com', '', 0, 'Udaipur', 'shreya@123'),
(10, 'eretsrtjd', 'dsdfhg', 0, 0, 'shreya@gmail.com', '', 0, 'Udaipur', 'shreya@123'),
(11, 'malisha', 'dharmendra', 1234599, 98765432, 'malishasoni@gmail.com', 'maheshwari mohalla', 313203, 'Udaipur', '123456789');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priceins`
--
ALTER TABLE `priceins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `priceins`
--
ALTER TABLE `priceins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
