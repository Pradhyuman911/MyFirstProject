
<?php
	include("adminhome.php");
?>
<style type="text/css">
	.abc{
		background-color: whitesmoke;
		padding: 50px;
		width: 300px;
		height: 450px;
	}
</style>
<div class="col-md-1">
	</div>
	<div class="col-md-8 abc" id="main-content" >
<form action="updatecat2.php" method="post">

	
	<center><h3>Product Details</h3></center>
<?php
	$id=$_GET['id'];
	$con=mysqli_connect("localhost","root","","ro project");
	$r=mysqli_query($con,"select * from image where id='$id'");
	$count = 0;
	
	while($row=mysqli_fetch_array($r))
	{
		$id=$row[0];
		$name=$row[1];
		$price=$row[2];
		
	}
?>
<input type="hidden" value="<?php echo $id ?>" name="id">
Category
	<select name='pname' class="form-control" >
	
		<option><?php echo $name?></option>
			<?php
				$con = mysqli_connect("localhost","root","","ro project");
				$sql = "select * from `category`";
				$count = 0;
				$rs = mysqli_query ($con,$sql);
				while ($row = mysqli_fetch_assoc($rs))
				{
					$pname = $row['name'];
					echo "<option>".$pname."</option>";
				}
						
			?>
	</select><br><br>
	Price
	<select name='price' class="form-control">
	
		<option><?php echo $price ?></option>
			<?php
				$con = mysqli_connect("localhost","root","","ro project");
				$sql = "select * from `priceins`";
				$count = 0;
				$rs = mysqli_query ($con,$sql);
				while ($row = mysqli_fetch_assoc($rs))
				{
					$price = $row['price'];
					echo "<option>".$price."</option>";
				}
						
			?>
	</select><br><br>
	
	<center><button  type="submit" class="btn btn-primary">Update</button>
	
	
				</form>	
			</div>
	</body>
</html>