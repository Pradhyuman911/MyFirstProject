<?php

	
	$name=$_POST["pname"];
	
	
		$con=mysqli_connect("localhost","root","","ro project");
		$sql="INSERT INTO `category`(`name`) VALUES ('$name')";
		$rs=mysqli_query($con,$sql);
		if($rs)
		{
			//echo"<script>
			//alert('Registration Successful....You may login now.');
			//window.location='login.php';
			//</script>";
			//echo"inserted";
			header("location:insertcat.php");
		}
		else
			echo"not inserted";

?>
