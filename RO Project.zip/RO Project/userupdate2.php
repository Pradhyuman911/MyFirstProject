<?php
	$id=$_POST["id"];
	$name=$_POST["name"];
	$fname=$_POST["fname"];
	$mnum1=$_POST["mnum1"];
	$mnum2=$_POST["mnum2"];
	$email=$_POST["email"];
	$address=$_POST["address"];
	$pincode=$_POST["pincode"];
	$city=$_POST["city"];
	$password=$_POST["password"];
		$con=mysqli_connect("localhost","root","","ro project");
		$sql="UPDATE `user` SET `uname`='$name',`fname`='$fname',`mnum1`='$mnum1',`mnum2`='$mnum2',`email`='$email',`address`='$address',`pincode`='$pincode',`city`='$city',`password`='$password' WHERE id='$id'";
		$rs=mysqli_query($con,$sql);
		if($rs)
		{
			echo"<script>
			alert('Update Successful....');
			window.location='userview.php';
			</script>";

			//header("location:`login.php");
		}
		else
			echo"not inserted";

?>

