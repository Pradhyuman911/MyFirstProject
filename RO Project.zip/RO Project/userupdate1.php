
<?php
	include("adminhome.php");
?>
<style type="text/css">
	.abc{
		background-color: whitesmoke;
		padding: 50px;
		width: 300px;
		height: 450px;
	}
</style>
<div class="col-md-1">
	</div>
	<div class="col-md-8 abc" id="main-content" >
<form action="userupdate2.php" method="post">

	
	<center><h3>Customer Details</h3></center>
<?php
	$id=$_GET['id'];
	$con=mysqli_connect("localhost","root","","ro project");
	$r=mysqli_query($con,"select * from user where id='$id'");
	$count = 0;
	
	
	
	while($row=mysqli_fetch_array($r))
	{
		$id=$row[0];
		$name=$row[1];
		$fname=$row[2];
		$mnum1=$row[3];
		$mnum2=$row[4];
		$email=$row[5];
		$address=$row[6];
		$pincode=$row[7];
		$city=$row[8];
		$password=$row[9];
	}
?>
	
	<input type="hidden" value="<?php echo $id ?>" name="id">
	User Name<br>
		<input type='text' name='name' value="<?php echo $name ?>" class="form-control" required>
	Father's Name<br>
			<input type='text' name='fname' value="<?php echo $fname ?>"class="form-control"required>
					Mobile No.<br>
						<input type='text' name='mnum1' value="<?php echo $mnum1 ?>" class="form-control">
						<input type='text' name='mnum2'value="<?php echo $mnum2 ?>" class="form-control">
					Email Id<br>
						<input type='email' name='email' value="<?php echo $email ?>" class="form-control"required>
					Address<br>
						<textarea rows=3 cols=20 name="address"  class="form-control"><?php echo $address ?></textarea>
					Pincode<br>
						<input type='text' name='pincode' value="<?php echo $pincode ?>" class="form-control">
					City<br>
						<label for="state"></label>
						<select id="state" name="city" value="<?php echo $city ?>"class="form-control">
						<optgroup label="Rajasthan">
							<option value="Udaipur">Udaipur</option>
							<option value="Jaipur">Jaipur</option>
						</optgroup>
						<optgroup label="Gujrat">
							<option value="Ahmbdb">Ahmdbd</option>
							<option value="Gandhingr">Gandhingr</option>
						</optgroup>
						</select>
					Password<br>
						<input type='password' name='password' value="<?php echo $password ?>"class="form-control" required><br>
					<center><button  type="submit" class="btn btn-primary">Submit</button>
					</center>
					</form>
					
			</div>
	</body>
</html>