<?php
	$con=mysqli_connect("localhost","root","","ro project");
	$sql="select * from user where email='$_POST[email]'";
	$rs=mysqli_query($con,$sql);
	while($row=mysqli_fetch_assoc($rs))
		{
			if($row['email']==$_POST['email'])
			{
				if($row['password']==$_POST['password'])
					header("location:userhome.php");	
				else
					echo "wrong password";
			}
			else
			{
				echo "Wrong Email";
			}
		}
?>

				

