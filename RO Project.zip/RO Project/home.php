<!doctype html>
<head>
		<meta charset="UTF-8">
    	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/home.css">		
</head>
<title>RO Purifier</title>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <a class="navbar-brand" href="#">RO Purifier</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item ">
        <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
      </li>

        <li class="nav-item">
			<a class="nav-link" href="gallery.php">Gallery</a>
		</li>			
		<li class="nav-item">
			<a class="nav-link" href="contactus.php">Contact Us</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="adminlogout.php">Log Out</a>
		</li>

    </ul>
  </div>
  <span class="navbar-text">
                  <!-- Button login modal -->
            <button type="button" class="btn btn-warning mr-2" data-toggle="modal" data-target="#loginModal">
                Login
              </button>
            <!-- Button signup modal -->
            <button type="button" class="btn btn-warning mr-2" data-toggle="modal" data-target="#signupModal">
                SignUp
            </button>

</nav>

<!--this is for login-->
<div id="loginModal" class="modal fade" role="dialog">
        <div class=" modal-dialog modal-lg" role="content">
            <div class="modal-content">
                <div class="modal-header bg-secondary">
                    <h4 class="modal-title text-light">Login</h4>
                    <button type="button" class="close text-white" data-dismiss="modal">
                          &times;
                      </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label class="sr-only" for="email">Email address:</label>
                            <input type="email" class="form-control" placeholder="Enter email" id="email">
                        </div>
                        <div class="form-group">
                            <label class="sr-only" for="pwd">Password:</label>
                            <input type="password" class="form-control" placeholder="Enter password" id="pwd">
                        </div>
                        <div class="col-sm-auto">
                            <div class=" form-check">
                                <label class="form-check-label">
                                   <input class="form-check-input" type="checkbox"> Remember me
                              </label>
                            </div>
                        </div>
                        <div class="form-row">
                            <button type="button" class="btn btn-secondary ml-auto" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary ml-2">Sign In</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!--signup Modal -->
    <div class="modal fade" id="signupModal" role="dialog">
        <div class="modal-dialog modal-dialog-scrollable modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-secondary">
                    <h5 class="modal-title text-white" id="signupModalTitle">SignUp Here</h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>

                </div>
                <div class="modal-body">

                    <form>
                        <div class="form-group">
                            <label for="Username">UserName</label>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Choose a unique Username" required>
                        </div>

                        <div class="form-group">
                            <label for="Firstname">FirstName</label>
                            <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Firstname">
                        </div>
                        <div class="form-group">
                            <label for="Lastname">LastName</label>
                            <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Lastname">
                        </div>
                        <div class="form-group">
                            <label for="Email">Email address</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                        </div>

                        <div class="form-group">
                            <label for="Password1"> Choose a Password</label>
                            <input type="password" class="form-control" id="password1" name="password1" placeholder="Choose your Password" required>
                        </div>

                        <div class="form-group">
                            <label for="Password2"> Confirm Password</label>
                            <input type="password" class="form-control" id="password2" name="password2" placeholder="Enter Password Again" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-primary ml-3">Close</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


  <div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="photos/photo.jpg" alt="Los Angeles" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Los Angeles</h3>
        <p>We had such a great time in LA!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="photos/photo.jpg" alt="Chicago" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Chicago</h3>
        <p>Thank you, Chicago!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="photos/photo.jpg" alt="New York" width="1100" height="500">
      <div class="carousel-caption">
        <h3>New York</h3>
        <p>We love the Big Apple!</p>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

	<section class="my-5">
		<div class="py-4">
			<h4 class="text-center display-3 font-weight-normal ">NEXT-GEN RO PURIFIERS</h3>	
		</div>

		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-3 col-md-6 col-12">
					<img src="photos/img1.png" class="img-fluid aboutimg">
				</div>
				<div class="col-lg-9 col-md-6 col-12">
					<h3 class="display-4">To Protect Your Family</h3>
					<p class="py-3 font">The world's best RO purifiers that make your water 100% pure by removing even dissolved
impurities, as well as bacteria & viruses, now offer unmatched benefits. These Next-Gen RO purifiers
maintain essential natural minerals in water and display minerals & purity on the digital screen.
So go ahead and change your water purifier now.		
					</p>
					<a href="gallery.php" class="btn btn-success">Check More</a>
				</div>
			</div>
		</div>
	</section>

	<section class="jumbotron jumbotron-fluid">
		<div class="pb-2">
			<h4 class="text-center display-3 font-weight-normal text-dark ">OUR SERIVES</h3>	
		</div>

		<div class="container-fluid" >
			<div class="row ">
				<div class="col-lg-3 col-md-3 col-12">
					<div class="card m-2 " style="width: 320px ">
					<h4 class="card-title text-center">PRIME PLUS</h4>
					<p class="text-center m-2">Water purifier with UV disinfection in storage tank to keep water pure</p>
						<img class="card-img-top" src="photos/prime.png" alt="Card image">
						<div class="card-body">						
							<p class="card-text text-center">MRP:$1000</p>
							<a href="#" class="btn btn-primary ">View Details</a>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-12">
					<div class="card m-2" style="width: 300px;">
					<h4 class="card-title text-center">GRAND</h4>
					<p class="text-center m-2">An advanced RO water purifier with multiple purification process and in-tank UV disinfection</p>
						<img class="card-img-top" src="photos/grand.png" alt="Card image" >
						<div class="card-body">
							<p class="card-text text-center">MRP:$1000</p>
							<a href="#" class="btn btn-primary ">View Details</a>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-12">
					<div class="card m-2" style="width: 300px;">
					<h4 class="card-title text-center">STAR</h4>
					<p class="text-center m-2">Technologically Advanced Water Purifier with Futuristic Multiple Purification Process</p>
						<img class="card-img-top" src="photos/star.png" alt="Card image ">
						<div class="card-body">
							<p class="card-text text-center">MRP:$1200</p>
							<a href="#" class="btn btn-primary ">View Details</a>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-12">
					<div class="card m-2" style="width: 300px;">
					<h4 class="card-title text-center">GRAND PLUS</h4>
					<p class="text-center m-2">Wall Mountable / Counter-Top Water Purifier with Multiple Purification & Detachable Storage Tank</p>
						<img class="card-img-top" src="photos/ro4.png" alt="Card image " >
						<div class="card-body">
							<p class="card-text text-center">MRP:$1200</p>
							<a href="#" class="btn btn-primary ">View Details</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="container-fluid bg-light">
		<div class="row">
			<div class="col-12 text-center mt-5">
				<h4>Removes Dissolved Impurities from Water</h4>
				<img src="photos/f1.png">
			</div>
			<div class="col-12 text-center mt-2 font-weight-light ">
				<p style="font-size: 1.5em ;">Boiling the water or using conventional purifiers (UV) only kills bacteria and viruses
					 but does not remove dissolved impurities. RO Purifiers however, 
					besides removing bacteria and viruses also remove harmful dissolved impurities.</p>
			</div>
		</div>
		<div class="row">
			<div class="col-12 text-center mt-5">
				<h4>Mineral RO Technology</h4>
				<img src="photos/f3.png">
			</div>
			<div class="col-12 text-center mt-2 font-weight-light">
				<p style="font-size: 1.5em ;">KENT's patented Mineral ROTM Technology retains essential natural minerals in purified
				 water using the TDS Controller, thereby providing safe and tasty drinking water.</p>
			</div>
		</div>
		<div class="row">
			<div class="col-12 text-center mt-5">
				<h4>Multiple Purification for Pure Water</h4>
				<img src="photos/f2.png">
			</div>
			<div class="col-12 text-center mt-2 font-weight-light">
				<p style="font-size: 1.5em ;">RO Purification followed by UV/UF Purification removes 
				dissolved impurities, kills bacteria & viruses and make water pure.</p>
			</div>			
		</div>
		<div class="row">
			<div class="col-12 text-center mt-5">
				<h4>Save Water Technology</h4>
				<img src="photos/f4.png">
			</div>
			<div class="col-12 text-center mt-2 font-weight-light">
				<p style="font-size: 1.5em ;">Conventional RO purifiers reject a lot of the water and 
				retain only a small quantity of water as purified. KENT’s Save Water Technology uses a 
				computer-controlled process to recover more water as purified. The rejected 
				water is stored in a separate tank which can be utilized for mopping and washing.</p>
			</div>			
		</div>
	</section>

	   <!--footer-->
    <div class="jumbotron-fluid bg-warning" style="height: 50px;">
    </div>
    <footer class="footer bg-dark ">
        <div class="container py-5">
            <div class="row text-white ">
                <div class="col-3 offset-1 col-sm-2 ">
                    <h5>Links</h5>
                    <ul class="list-unstyled ">
                        <li><a href="home.php" class="text-white ">Home</a></li>
                        <li><a href="gallery.php" class="text-white">Gallery</a></li>
                        <li><a href="contactus.php" class="text-white ">Contact</a></li>
                        <li><a href="#" class="text-white ">Logout</a></li>
                    </ul>
                </div>
                <div class="col col-md-3">
                    <h5>Other Products</h5>
                  <ul class="list-unstyled ">
                    <li><a href="#"class="text-white font-italic ">Water Purifiers</a></li>
                    <li><a href="#"class="text-white font-italic">Air Purifiers</a></li>
                    <li><a href="#"class="text-white font-italic">Water Softeners</a></li>
                    <li><a href="#"class="text-white font-italic">Cooking Appliances</a></li>
                    <li><a href="#"class="text-white font-italic">Vaccum Cleaners</a></li>
                  </ul>
                </div>
                <div class="col col-md-3 ">
                    <h5>Our Address</h5>
                    <address>
                  121, Clear Water Bay Road<br>
                  Clear Water Bay, Kowloon<br>
                  HONG KONG<br>
                  <i class="fa fa-phone fa-lg "></i>: +852 1234 5678<br>
                  <i class="fa fa-fax fa-lg "></i>: +852 8765 4321<br>
                  <i class="fa fa-envelope fa-lg "></i>: <a href="mailto:hrkuch@gmail.com "class="text-white">hr@gmail.com </a>
               </address>
                </div>
                <div class="col col-md-3 ">
                    <h5>Location</h5>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3622.365069616518!2d73.98145771431336!3d24.78294978409051!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xec70bf95dc9a1f17!2sVijayvargiya%20General%20Store!5e0!3m2!1sen!2sin!4v1593876453574!5m2!1sen!2sin" width="300" height="300" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                </div>
            </div>
        </div>
    </footer>
		<script src="js/jquery.js"></script>
		<script src="js/bootstrap.min.js"></script>
</body>
</html>