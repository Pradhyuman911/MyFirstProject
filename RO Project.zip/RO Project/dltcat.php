<?php
	include("adminhome.php");
?>
<style type="text/css">
	.abc{
		background-color: whitesmoke;
		padding: 50px;
		width: 300px;
		height: 450px;
	}
</style>
	<div class="col-md-1">
	</div>
	<div class="col-md-8 abc" id="main-content" >
	
	<center><h3>Customer Details</h3></center>
<?php
	$con=mysqli_connect("localhost","root","","ro project");
	$r=mysqli_query($con,"select * from image");
	$count = 0;
	
	
	echo"<table border='1' align='center' cellspacing=0 cellpadding=5>";
	echo"<tr><th>S.N.</th>
	
	<th>Name</th>
	<th>Price</th>
	<th>Image</th>
	<th>Delete</th>
	</tr>";
	
	while($row=mysqli_fetch_array($r))
	{
		$id=$row[0];
		$count++;
		echo"<tr><td>",$count,"</td>";
		echo"<td>",$row[1],"</td>";
		echo"<td>",$row[2],"</td>";
		echo"<td>",$row[3],"</td>";
		echo"<td><a href='dltcat1.php?id=$id'>Delete</a></td>";
		echo"</tr>";
	}
?>
</table>
</div>
</div>
	</body>
</html>

