<?php
	include("adminhome.php");

?>

<style type="text/css">
	.abc{
		background-color: whitesmoke;
		padding: 50px;
		width: 300px;
		height: 450px;
	}
</style>

<div class="col-md-1">
	</div>
	<div class="col-md-8 abc" id="main-content" >
	
	<center><h3>Product Details</h3></center>
	<form action="addimg1.php" method="post" enctype="multipart/form-data">
	Category
	<select name='pname' class="form-control">
	
		<option>select</option>
			<?php
				$con = mysqli_connect("localhost","root","","ro project");
				$sql = "select * from `category`";
				$count = 0;
				$rs = mysqli_query ($con,$sql);
				while ($row = mysqli_fetch_assoc($rs))
				{
					$pname = $row['name'];
					echo "<option>".$pname."</option>";
				}
						
			?>
	</select><br><br>
	Price
	<select name='price' class="form-control">
	
		<option>select</option>
			<?php
				$con = mysqli_connect("localhost","root","","ro project");
				$sql = "select * from `priceins`";
				$count = 0;
				$rs = mysqli_query ($con,$sql);
				while ($row = mysqli_fetch_assoc($rs))
				{
					$price = $row['price'];
					echo "<option>".$price."</option>";
				}
						
			?>
	</select><br><br>
	Choose Photo
	<input type="file" name="img" class="form-control"><br><br>
	<center><button  type="submit" class="btn btn-primary">Save</button>
</div>
</div>
</body>
</html>