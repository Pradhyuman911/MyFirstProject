<html>
	<head>
		<title>Login Page</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<script src="js/jquery.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	
	<style type="text/css">
	#side_bar
	{
		background-color: whitesmoke;
	
		padding: 50px;
		height:550px;
	}
	img{
		border-radius:50%;
	}
	</style>
	
	<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
			<div class="container-fluid">
				<div class="navbar-header">
				<a class="navbar-brand" href="">RO Purifier</a>
				</div>
				
				<ul class="nav navbar-nav navbar-right">
					<li class="nav-item">
						<a class="nav-link" href="adminlogin.php">Admin Login</a>
					</li>
				</ul>
			
				</div>
		</nav>
			<div class="row">
				<div class="col-md-3">
				</div>
				<div class="col-md-6" id="side_bar">
				<center>
					<h1>User Login</h1>
						<img src="databaseimg/admin.jpg">
					<br><br></center>
					<form action="userlogin.php" method="post">
						Email Id 	<input type="email" name="email" class="form-control" required><br><br>
						Password 	<input type="password" name="password" class="form-control" required><br><br>
						<center><button  type="submit" class="btn btn-primary">Log In</button>
						<br>
					</form>
					<form action="usersignin1.php" method="post">
						<br><br>Don't have an account<br><button  type="submit" class="btn btn-primary">Sign In</button>
					</center>
					</form>
				</div>
				<div class="col-md-3">
				</div>	
			</div>
	</body>
</html>





	