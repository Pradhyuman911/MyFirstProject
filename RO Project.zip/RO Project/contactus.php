<?php
	include("userhome.php")
?>
<html>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3622.365069616518!2d73.98145771431336!3d24.78294978409051!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xec70bf95dc9a1f17!2sVijayvargiya%20General%20Store!5e0!3m2!1sen!2sin!4v1593876453574!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
</html>