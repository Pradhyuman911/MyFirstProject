<?php
	$id=$_GET['id'];
	$con=mysqli_connect("localhost","root","","ro project");
	$sql="DELETE FROM `image` WHERE id='$id'";
	$rs=mysqli_query($con,$sql);
	if($rs)
		header("location:dltcat.php");
	else
		echo"record not deleted";

?>