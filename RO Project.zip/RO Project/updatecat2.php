<?php
	$id=$_POST["id"];
	$name=$_POST["pname"];
	$price=$_POST["price"];
	
	
		$con=mysqli_connect("localhost","root","","ro project");
		$sql="UPDATE `image` SET `pname`='$name',`price`='$price' WHERE id='$id'";
		$rs=mysqli_query($con,$sql);

		if($rs)
		{
			echo"<script>
			alert('Update Successful....');
			window.location='updatecat.php';
			</script>";
			
			//header("location:`login.php");
		}
		else
			echo"not inserted";

?>

