<?php
	include("adminhome.php");
?>

<style type="text/css">
	.abc{
		background-color: white;
		padding: 50px;
		width: 300px;
		height: 550px;
	}
	img{
		padding:10px;
	}
</style>

<div class="col-md-1">
	</div>
	<div class="col-md-8 abc" id="main-content" >
<?php
	$con = mysqli_connect("localhost","root","","ro project");
	$sql = "select * from `image`";
	$count = 0;
	$rs = mysqli_query ($con,$sql);
	while ($row = mysqli_fetch_assoc($rs))
	{
		$name=$row['pname'];
		$photo ="photos/".$row ["img"];
		echo"<a href='$photo' download>";
		echo "<img src='$photo' title='$name' height=200 width=200>";
		echo"</a>";
		
	}
	
?>
</div>
</div>
</body>
</body>