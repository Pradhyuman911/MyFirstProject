<html>
	<head>
		<title>SignIn Page</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<script src="js/jquery.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	
	<style type="text/css">
	#side_bar
	{
		background-color: whitesmoke;
		padding: 50px;
		height:800px;
	}
	</style>
	<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
			<div class="container-fluid">
				<div class="navbar-header">
				<a class="navbar-brand" href="">RO Purifier</a>
				</div>
				<ul class="nav navbar-nav navbar-right">
					<li class="nav-item">
						<a class="nav-link" href="adminlogin.php">Admin Login</a>
					</li>
				</ul>
			</div>
		</nav>
		<div class="row">
				<div class="col-md-3">
				</div>
				<div class="col-md-6" id="side_bar">
				<center><h1>Sign In</h1><br></center>
					<form action="usersignin.php" method="post">
					User Name<br>
						<input type='text' name='name' class="form-control" required>
					Father's Name<br>
						<input type='text' name='fname'class="form-control"required>
					Mobile No.<br>
						<input type='text' name='mnum1'class="form-control">
						<input type='text' name='mnum2'class="form-control">
					Email Id<br>
						<input type='email' name='email'class="form-control"required>
					Address<br>
						<textarea rows=3 cols=20 name="address"class="form-control"></textarea>
					Pincode<br>
						<input type='text' name='pincode'class="form-control">
					City<br>
						<label for="state"></label>
						<select id="state" name="city"class="form-control">
						<optgroup label="Rajasthan">
							<option value="Udaipur">Udaipur</option>
							<option value="Jaipur">Jaipur</option>
						</optgroup>
						<optgroup label="Gujrat">
							<option value="Ahmbdb">Ahmdbd</option>
							<option value="Gandhingr">Gandhingr</option>
						</optgroup>
						</select>
					Password<br>
						<input type='password' name='password'class="form-control" required><br>
					<center><button  type="submit" class="btn btn-primary">Sign In</button>
					</center>
					</form>
				<div class="col-md-3">
				</div>	
			</div>
	</body>
</html>


<!--</style><center><h1>Sign In</h1><br></center>
					<form action="usersignin.php" method="post">
					User Name<br>
						<input type='text' name='name' class="form-control" required>
					Father's Name<br>
						<input type='text' name='fname'class="form-control"required>
					Mobile No.<br>
						<input type='text' name='mnum1'class="form-control">
						<input type='text' name='mnum2'class="form-control">
					Email Id<br>
						<input type='email' name='email'class="form-control"required>
					Address<br>
						<textarea rows=3 cols=20 name="address"class="form-control"></textarea>
					Pincode<br>
						<input type='text' name='pincode'class="form-control">
					City<br>
						<label for="state"></label>
						<select id="state" name="city"class="form-control">
						<optgroup label="Rajasthan">
							<option value="Udaipur">Udaipur</option>
							<option value="Jaipur">Jaipur</option>
						</optgroup>
						<optgroup label="Gujrat">
							<option value="Ahmbdb">Ahmdbd</option>
							<option value="Gandhingr">Gandhingr</option>
						</optgroup>
						</select>
					Password<br>
						<input type='password' name='password'class="form-control" required><br>
					<center><button  type="submit" class="btn btn-primary">Sign In</button>
					</center>
					</form>
				</div>-->