<html>
	<head>
		<title>User Home Page</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<script src="js/jquery.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	
	<style type="text/css">
	#side_bar
	{
		background-color: whitesmoke;
		padding: 50px;
		width: 300px;
		height: 450px;
	}
	</style>
	
	<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
			<div class="container-fluid">
				<div class="navbar-header">
				<a class="navbar-brand" href="">RO Purifier</a>
				</div>
				
				<ul class="nav navbar-nav navbar-right">
				<li class=nav-item">
					<input type="text" placeholder="Search..">
				</li>
					<li class="nav-item">
						<a class="nav-link" href="gallery.php">Gallery</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="">Cart</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="contactus.php">Contact Us</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="">Log Out</a>
					</li>
				</ul>
			
				</div>
		</nav>
<style>			
			
	img{
		padding:10px;
	}
</style>
<div class="row">
<div class="col-md-3">
	</div>
	<div class="col-md-8" id="main-content" >
<?php
	$con = mysqli_connect("localhost","root","","ro project");
	$sql = "select * from `image`";
	$count = 0;
	$rs = mysqli_query ($con,$sql);
	while ($row = mysqli_fetch_assoc($rs))
	{
		$name=$row['pname'];
		$photo ="photos/".$row ["img"];
		echo"<a href='$photo' download>";
		echo "<img src='$photo' title='$name' height=200 width=200>";
		echo"</a>";
		
		
	}
	
?>
<div class="col-md-3">
	</div>
</div>
</div>
	</body>
</html>