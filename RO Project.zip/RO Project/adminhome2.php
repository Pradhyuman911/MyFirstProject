<html>
	<head>
		<title>Admin Home Page</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<script src="js/jquery.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	
	<style type="text/css">
	#side_bar
	{
		background-color: whitesmoke;
		padding: 50px;
		width: 300px;
		height: 550px;
	}
	img{
		width:600px;
	}
	
	</style>
	
	<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
			<div class="container-fluid">
				<div class="navbar-header">
				<img src="photos/ro.jpg" style="border-radius:50%;width:80px;height:80px;">
				<a class="navbar-brand" href="adminhome.php">RO Purifier</a>
				</div>
				<ul class="nav navbar-nav navbar-right">
					<li class="nav-item">
						<a class="nav-link" href="admingallery.php">Gallery</a>
					</li>
					
					<li class="nav-item">
						<a class="nav-link" href="adminlogout.php">Log Out</a>
					</li>
				</ul>
			</div>
		</nav>
		
			<div class="row">
				<div class="col-md-3" id="side_bar">
					
					<ul>
						<li>
							<a href="insertcat.php">Insert category</a>
						</li>
						<li>
							<a href="priceins.php">Insert Price</a>
						</li>
						<li>
							<a href="addimg.php">Insert Image</a>
						</li>
						<li>
							<a href="updatecat.php">Update</a>
						</li>
						<li>
							<a href="dltcat.php">Delete</a>
						</li>
						<li>
							<a href="viewcat.php">view</a>
						</li>
					</ul>
					<h3>Users</h3>
					<ul>
						<li>
							<a href="userupdate.php">Update</a>
						</li>
						<li>
							<a href="userdlt.php">Delete</a>
						</li>
						<li>
							<a href="userview.php">view</a>
						</li>
					</ul>
					<h3>Order Details</h3>
					<ul>
						<li>
							<a href="">Update</a>
						</li>
						<li>
							<a href="">Delete</a>
						</li>
						<li>
							<a href="">view</a>
						</li>
					</ul>
					<div class="col-md-9" id="main-content" >
					<img src="photos/photo.jpg">
					</div>
				</div>
				</div>
				
			
	</body>
</html>
