<html>
	<head>
		<title>Admin Home Page</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<script src="js/jquery.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	
	<style type="text/css">
	#side_bar
	{
		background-color: whitesmoke;
		padding: 50px;
		width: 300px;
		height: 550px;
	}
	
	</style>
	
	<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
			<div class="container-fluid">
				<div class="navbar-header">
				<img src="photos/ro.jpg" style="border-radius:50%;width:80px;height:80px;">
				<a class="navbar-brand" href="adminhome2.php">RO Purifier</a>
				</div>
				<ul class="nav navbar-nav navbar-right">
					<li class="nav-item">
						<a class="nav-link" href="admingallery.php">Gallery</a>
					</li>
					
					<li class="nav-item">
						<a class="nav-link" href="adminlogout.php">Log Out</a>
					</li>
				</ul>
			</div>
		</nav>
		
			<div class="row">
				<div class="col-md-3" id="side_bar">
					
					<ul>
						<li>
							<a href="insertcat.php">Insert category</a>
						</li>
						<li>
							<a href="priceins.php">Insert Price</a>
						</li>
						<li>
							<a href="addimg.php">Insert Image</a>
						</li>
						<li>
							<a href="updatecat.php">Update</a>
						</li>
						<li>
							<a href="dltcat.php">Delete</a>
						</li>
						<li>
							<a href="viewcat.php">view</a>
						</li>
					</ul>
					<h3>Users</h3>
					<ul>
						<li>
							<a href="userupdate.php">Update</a>
						</li>
						<li>
							<a href="userdlt.php">Delete</a>
						</li>
						<li>
							<a href="userview.php">view</a>
						</li>
					</ul>
					<h3>Order Details</h3>
					<ul>
						<li>
							<a href="">Update</a>
						</li>
						<li>
							<a href="">Delete</a>
						</li>
						<li>
							<a href="">view</a>
						</li>
					</ul>
				</div>
				
			<!--</div>
	</body>
</html>-->


<!--<div id="myCarousel" class="carousel slide" data-ride="carousel">

        <div class="carousel-inner ">
            <div class="carousel-item c1 active">
                <img src="d:/work/images/slider-4.jpg" class="d-block img-fluid" alt="...">
                <div class="container">
                    <div class="carousel-caption d-block d-none d-md-block">
                        <h1>Small Efforts Make Big Change.</h1>
                        <p>Volunteers do not necessarily have the time they just have the heart.</p>
                    </div>
                </div>
            </div>
            <div class="carousel-item c1">
                <img src="d:/work/images/slider-4.jpg" class="d-block img-fluid" alt="...">
                <div class="container">
                    <div class="carousel-caption d-block d-none  d-md-block">
                        <h1>The Most Effective Way To Do It,Is To Do It.</h1>
                        <p>Believe in possibilities. Believe in human potential. Believe in yourself and you’ll have the power to change your life.</p>
                    </div>
                </div>
            </div>
            <div class="carousel-item  c1">
                <img src="d:/work/images/slider-4.jpg" class="d-block img-fluid" alt="...">

                <div class="container">
                    <div class="carousel-caption d-block  d-none d-md-block">
                        <h1>A Child Is An Uncut Diamond</h1>
                        <p>If you have no one to encourage you, instead of using that as an excuse for failure, encourage yourself and use that as a reason why you must succeed.</p>
                    </div>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev " href="#myCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next " href="#myCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <!-- container-fluid after carousel-->


   <!-- <div class="container-fluid bg-secondary text-white">
        <div class="row">
            <div class="col-lg-9 my-3">
                <p>A lot of work goes down at the grass root level in villages in the remotest corners as well as the most populous metros across India, with schools, individuals and government bodies. We need your contributions to keep coming in. </p>
            </div>
            <!-- Button Donation -->
           <!-- <p><a href="d:/work/html/donation.html" role="button" class="btn btn-warning my-4 ml-4">Donation</a></p>
        </div>
    </div>-->



	