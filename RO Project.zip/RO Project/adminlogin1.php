<?php
	$email=$_POST['email'];
	$password=$_POST['password'];
					$con=mysqli_connect("localhost","root","","ro project");
					$sql="select * from login where email='$email'";
					$rs=mysqli_query($con,$sql);
					while($row=mysqli_fetch_assoc($rs))
					{
						if($row['email']==$email)
						{
							if($row['password']==$password)
							{
									header("location:adminhome.php");
							}
							else
							{
								echo "wrong password";
							}
						}
						else
						{
							echo "Wrong Email";
						}
					}
				
			?>
		