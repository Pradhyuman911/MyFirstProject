<?php
	$con = mysqli_connect("localhost","root","","ro project");
	if(move_uploaded_file($_FILES['img']['tmp_name'],"photos/".$_FILES['img']['name']))
	{
		$pname= $_POST["pname"];
		$price=$_POST["price"];
		
		$img = $_FILES['img']['name'];
		
		$sql = "INSERT INTO `image`(`pname`, `price`, `img`) VALUES ('$pname','$price','$img')";
		$rs = mysqli_query($con,$sql);
		if($rs)
			
			header("location:addimg.php");
	}
	else
		echo "not upload";
?>