<?php
	include("adminhome.php");
?>
	
<style type="text/css">
	.abc{
		background-color: whitesmoke;
		padding: 50px;
		width: 300px;
		height: 450px;
	}
</style>

<div class="col-md-1">
	</div>
	<div class="col-md-8 abc" id="main-content" >
	<form action="priceins1.php" method="post">
	<center><h3>Product Details</h3></center>

	
	Price <input type='text' name='price' class="form-control">
	
	<center><button  type="submit" class="btn btn-primary">Submit</button>
					</center>
	</div>
</div>
</body>
</html>
			