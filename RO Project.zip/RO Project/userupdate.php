<?php
	include("adminhome.php");
?>
<style type="text/css">
	.abc{
		background-color: whitesmoke;
		padding: 50px;
		width: 300px;
		height: 450px;
	}
</style>
	<div class="col-md-1">
	</div>
	<div class="col-md-8 abc" id="main-content" >
	
	<center><h3>Customer Details</h3></center>
<?php
	$con=mysqli_connect("localhost","root","","ro project");
	$r=mysqli_query($con,"select * from user");
	$count = 0;
	
	
	echo"<table border='1' align='center' cellspacing=0 cellpadding=5>";
	echo"<tr><th>S.N.</th>
	<th>Name</th>
	<th>Father's Name</th>
	<th>mobile No.1</th>
	<th>mobile No.2</th>
	<th>Email Id</th>
	<th>Address</th>
	<th>City</th>
	<th>Pincode</th>
	<th>Update</th>
	</tr>";
	
	while($row=mysqli_fetch_array($r))
	{
		$id=$row[0];
		$count++;
		echo"<tr><td>",$count,"</td>";
		echo"<td>",$row[1],"</td>";
		echo"<td>",$row[2],"</td>";
		echo"<td>",$row[3],"</td>";
		echo"<td>",$row[4],"</td>";
		echo"<td>",$row[5],"</td>";
		echo"<td>",$row[6],"</td>";
		echo"<td>",$row[7],"</td>";
		echo"<td>",$row[8],"</td>";
		echo"<td><a href='userupdate1.php?id=$id'>Update</a></td>";
		echo "</tr>";
	}
?>
</table>
</div>
</div>
	</body>
</html>

