<?php

	$name=$_POST["name"];
	$fname=$_POST["fname"];
	$mnum1=$_POST["mnum1"];
	$mnum2=$_POST["mnum2"];
	$email=$_POST["email"];
	$address=$_POST["address"];
	$pincode=$_POST["pincode"];
	$city=$_POST["city"];
	$password=$_POST["password"];
		$con=mysqli_connect("localhost","root","","ro project");
		$sql="INSERT INTO `user`(`uname`, `fname`, `mnum1`, `mnum2`, `email`, `address`, `pincode`, `city`, `password`) VALUES ('$name','$fname','$mnum1','$mnum2','$email','$address','$pincode','$city','$password')";
		$rs=mysqli_query($con,$sql);
		if($rs)
		{
			echo"<script>
			alert('Registration Successful....You may login now.');
			window.location='login.php';
			</script>";

			//header("location:`login.php");
		}
		else
			echo"not inserted";

?>
