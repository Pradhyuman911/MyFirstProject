<html>
	<head>
		<title>Student Login Page</title>
	</head>
	<body>
		<center>
			<h1>Student Login</h1><br><br> 
			<form action="" method="post">
				Email Id:<input type="email" name="email" required><br><br>
				Password:<input type="password" name="password" required><br><br>
				<input type="submit" name="submit" value="login"><br><br>
			<form>	
			<?php
				if(isset($_POST['submit']))
				{
					$con=mysqli_connect("localhost","root","","ro project");
					$sql="select * from login where email='$_POST[email]'";
					$rs=mysqli_query($con,$sql);
					while($row=mysqli_fetch_assoc($rs))
					{
						if($row['email']==$_POST['email'])
						{
							if($row['password']==$_POST['password'])
							{
									echo"Login Successful";
									//header("location:studenthome.php");
							}
							else
							{
								echo "wrong password";
							}
						}
						else
						{
							echo "Wrong Email";
						}
					}
				}
			?>
		</center>
	</body>
</html>