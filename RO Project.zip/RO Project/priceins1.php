<?php

	
	$price=$_POST["price"];
	
	
		$con=mysqli_connect("localhost","root","","ro project");
		$sql="INSERT INTO `priceins`(`price`) VALUES ('$price')";
		$rs=mysqli_query($con,$sql);
		if($rs)
		{
			//echo"<script>
			//alert('Registration Successful....You may login now.');
			//window.location='login.php';
			//</script>";
			//echo"inserted";
			header("location:priceins.php");
		}
		else
			echo"not inserted";

?>
