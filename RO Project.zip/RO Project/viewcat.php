<?php
	include("adminhome.php");
?>
<style type="text/css">
	.abc{
		background-color: whitesmoke;
		padding: 50px;
		width: 300px;
		height: 450px;
	}
</style>
	<div class="col-md-1">
	</div>
	<div class="col-md-8 abc" id="main-content" >
	
	<center><h3>Customer Details</h3></center>
<?php
	$con=mysqli_connect("localhost","root","","ro project");
	$r=mysqli_query($con,"select * from image");
	$count = 0;
	
	
	echo"<table border='1' align='center' cellspacing=0 cellpadding=5>";
	echo"<tr>
	<th>Image</th>
	<th>Name</th>
	<th>Price</th>
	
	</tr>";
	
	while($row=mysqli_fetch_assoc($r))
	{
		$count++;
		
		echo"<td>";
		$photo ="photos/".$row ["img"];
		echo"<a href='$photo' download>";
		echo "<img src='$photo' height=200 width=200>";
		echo"</a>";
		
		
		echo"</td>";
		echo"<td>",$row["pname"],"</td>";
		echo"<td>",$row["price"],"</td>		
		</tr>";
	}
?>
</table>
</div>
</div>
	</body>
</html>

